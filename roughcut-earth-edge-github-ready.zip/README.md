# Earth & Edge website starter

This is a static website with fully editable placeholder text and sections. It uses the selected Earth & Edge colours, with illustrative (not historically verified) hex codes.

## Files
- `index.html` — replace headings, paragraphs, links and placeholder labels with your content.
- `styles.css` — styling and the colour palette (at the top).

## Publish on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html` and `styles.css` in the repository root (not the ZIP).
3. In repository **Settings → Pages**, choose **Deploy from a branch** and select `main` / `(root)`.
4. Save and use the published Pages URL.

The email `replace-me@example.com` is a placeholder. Change it before publishing a live contact link. The coloured image blocks are visual placeholders, not actual photos.
